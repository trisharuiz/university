package com.example.connectfour;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.fragment.app.Fragment;

public class BoardFragment extends Fragment {

    String GAME_STATE = "gameState";
    ConnectFourGame mGame;
    GridLayout mGrid;

    // replace oncreate with oncreateview
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the fragment_board layout
        View view = inflater.inflate(R.layout.fragment_board, container, false);

        // Instantiate mGrid to GridLayout with a unique ID in fragment_board
        mGrid = view.findViewById(R.id.board_grid);

        // Iterate through the collection of Button elements to set an onClick listener
        for (int i = 0; i < mGrid.getChildCount(); i++) {
            View child = mGrid.getChildAt(i);
            if (child instanceof Button) {
                Button button = (Button) child;
                button.setOnClickListener(this::onButtonClick);
            }
        }

        //instantiate the member variable of class ConnectFourGame
        mGame = new ConnectFourGame();

        if (savedInstanceState == null) {
            // Call method startGame
            startGame();
        } else {
            // Declare local variable, data type String, to store the game state (i.e., gameState)
            String gameState = savedInstanceState.getString(GAME_STATE);

            // Call method setState in class ConnectFourGame, pass local variable gameState as an argument
            mGame.setState(gameState);

            // Call method setDis
            setDisc();
        }

        return view;
    }
    private void startGame() {
        mGame.newGame();
        setDisc();
    }
    public void setDisc() {
        for (int buttonIndex = 0; buttonIndex < mGame.DISCS; buttonIndex++) {

            // Instantiate an instance of class Button for the current member of the collection (i.e., gridButton)
            Button gridButton = (Button) mGrid.getChildAt(buttonIndex);


            // Find the button’s row and column

            int row = buttonIndex / 6;
            int col = buttonIndex % 6;

            // Instantiate an instance of class Drawable for the three drawable discs in res/drawable
            Drawable circleWhite = ContextCompat.getDrawable(getActivity(), R.drawable.circle_white);
            Drawable circleBlue = ContextCompat.getDrawable(getActivity(), R.drawable.circle_blue);
            Drawable circleRed = ContextCompat.getDrawable(getActivity(), R.drawable.circle_red);

            // Set each Drawable object equal to class.method DrawableCompat.wrap
            circleWhite = DrawableCompat.wrap(circleWhite);
            circleBlue = DrawableCompat.wrap(circleBlue);
            circleRed = DrawableCompat.wrap(circleRed);


            // Get the value of the element stored in the current row and column
            int discValue = mGame.getDisc(row, col);
           // Log.i("SET DISC",row+""+col+String.valueOf(discValue));
            switch (discValue) {
                case 1:
                    gridButton.setBackground(circleBlue);
                    break;
                case 2:
                gridButton.setBackground(circleRed);
                    break;
                case 0:
                    gridButton.setBackground(circleWhite);
                    break;
            }

        }
    }

    // Define onButtonClick method
    private void onButtonClick(View view) {
        // Find the button's row and col
        int buttonIndex = mGrid.indexOfChild(view);
        int row = buttonIndex / ConnectFourGame.ROW;
        int col = buttonIndex % ConnectFourGame.COL;

        mGame.selectDisc(row,col);

        setDisc();


        if (mGame.isGameOver()) {
            Toast.makeText(this.requireActivity(), R.string.congrats, Toast.LENGTH_SHORT).show();
            startGame();
            setDisc();
        }


    }
    // Override onSaveInstanceState
    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(GAME_STATE, mGame.getState());
    }
}