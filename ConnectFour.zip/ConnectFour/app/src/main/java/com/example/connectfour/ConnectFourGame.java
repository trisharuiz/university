package com.example.connectfour;

import android.util.Log;

public class ConnectFourGame {

    public static final int ROW = 7;
    public static final int COL = 6;
    public static final int EMPTY = 0;
    public static final int BLUE = 1;
    public static final int RED = 2;
    public static final int DISCS = 42;

    public int player;
    private int[][] board;


    public ConnectFourGame() {
        board = new int[7][6];
        player = BLUE;
    }

    //initialize a new game
    public void newGame(){
        for (int[] row : board ) {
            for (int num : row) {
                num = 0;
            }
        }
    }
    public String getState() {
        StringBuilder stringBuilder = new StringBuilder();

        for (int[] row : board ) {
            for (int num : row) {
                stringBuilder.append(num);
            }
        }

        return stringBuilder.toString();
    }

    public void setState(String gameState) {
        int index = 0;
        for (int row = 0; row < ROW; row++) {
            for (int col = 0; col < COL; col++) {

                board[row][col] = gameState.charAt(index);
                index += 1;
            }
        }


    }
    public int getDisc(int row, int col) {

        return board[row][col];
    }
    public void selectDisc(int row, int col) {
        // Iterate through the array boardGrid rows to find the first empty row/column based on the parameter col
        for (int i = ROW - 1; i >= 0; i--) {
            if (board[i][col] == 0) {
                // Set the element in the array to the current player
                board[i][col] = player;
               // Log.i("SELECTED DISC", i+""+col+String.valueOf(getDisc(i,col)));

                // Switch players
                if (player == RED) {
                    player = BLUE;
                }else if  (player == BLUE){
                    player = RED;
                }

                // Break out of the loop after a disc has been placed
                break;
            }
        }
    }
    public boolean isGameOver() {
        //if player win games is over
        if (isWin()) {
            return true;
        }

        // check if there is an empty disc then game is NOT over
        for (int row = 0; row < ROW; row++) {
            for (int col = 0; col < COL; col++) {
               // Log.i(String.valueOf(getDisc(row,col))+board[row][col]+"HHEEERREEE","ERROR");
                if (getDisc(row,col) == EMPTY) {
                    return false;
                }
            }
        }
        return true; // board game is full
    }

    public boolean isWin() {

        if(checkHorizontal() || checkVertical()){
            return true;
        }
        return false;
    }

    private boolean checkHorizontal() {
        for (int row = 0; row < ROW; row++) {
            for (int col = 0; col <= COL - 4; col++) {
                int disc = getDisc(row,col);
                Log.i("CHECKING",String.valueOf(board[row][col])+String.valueOf(board[row][col+1])+String.valueOf(board[row][col+2])+String.valueOf(board[row][col+3]));

                if (disc != EMPTY &&
                        disc == board[row][col + 1] &&
                        disc == board[row][col + 2] &&
                        disc == board[row][col + 3]) {
                    return true; // Four consecutive discs found horizontally
                }
            }
        }
        return false;
    }

    private boolean checkVertical() {
        for (int row = 0; row <= ROW - 4; row++) {
            for (int col = 0; col < COL; col++) {
                int disc = board[row][col];
                //Log.i("CHECKING",String.valueOf(board[row][col])+String.valueOf(board[row+1][col])+String.valueOf(board[row+2][col])+String.valueOf(board[row+3][col]));

                if (disc != EMPTY &&
                        disc == board[row + 1][col] &&
                        disc == board[row + 2][col] &&
                        disc == board[row + 3][col]) {
                    return true; // Four consecutive discs found vertically
                }
            }
        }
        return false;
    }

    private boolean checkDiagonal() {
        // Check from top-left to bottom-right
        for (int row = 0; row < ROW - 4; row++) {
            for (int col = 0; col < COL - 4; col++) {
                int disc = board[row][col];
                if (disc != EMPTY &&
                        disc == board[row + 1][col + 1] &&
                        disc == board[row + 2][col + 2] &&
                        disc == board[row + 3][col + 3]) {
                    return true; // Four consecutive discs found diagonally
                }
            }
        }

        // Check from top-right to bottom-left
        for (int row = 0; row < ROW - 4; row++) {
            for (int col = COL - 1; col >= 3; col--) {
                int disc = board[row][col];
                if (disc != EMPTY &&
                        disc == board[row + 1][col - 1] &&
                        disc == board[row + 2][col - 2] &&
                        disc == board[row + 3][col - 3]) {
                    return true; // Four consecutive discs found diagonally
                }
            }
        }

        return false;
    }


}
