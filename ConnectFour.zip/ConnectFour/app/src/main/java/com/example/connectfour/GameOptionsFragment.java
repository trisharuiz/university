package com.example.connectfour;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.fragment.app.Fragment;

public class GameOptionsFragment extends Fragment {
    private RadioButton easy;
    private RadioButton med;
    private RadioButton hard;

    private SharedPreferences sharedPreferences;
    public static final String GAME_MODE = "com.example.connectfour.gameoptions";
    public static final String LEVEL_PREFERENCE = "level_preference";

    // initializes options screen
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_game_options, container, false);

        easy = view.findViewById(R.id.radio_easy);
        med = view.findViewById(R.id.radio_medium);
        hard = view.findViewById(R.id.radio_hard);

        // Initialize SharedPreferences
        sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);

        // Set the selected radio button based on the saved level ID
        int levelId = sharedPreferences.getInt(LEVEL_PREFERENCE, R.string.easyMode);

        // Select the radio button matching the color ID
        int radioId = R.id.radio_easy;
        if (levelId == R.string.easyMode) {
            radioId = R.id.radio_easy;
        }
        else if (levelId == R.string.mediumMode) {
            radioId = R.id.radio_medium;
        }
        else if (levelId == R.string.mediumMode) {
            radioId = R.id.radio_medium;
        }

        RadioButton radio = view.findViewById(radioId);
        radio.setChecked(true);

        //setRadioButtonChecked(savedLevelId);

        // Add a click callback to all radio buttons
        RadioGroup radioGroup = view.findViewById(R.id.difficultyOptions);
        for (int i = 0; i < radioGroup.getChildCount(); i++) {
            radio = (RadioButton) radioGroup.getChildAt(i);
            radio.setOnClickListener(this::onLevelSelected);
        }

        return view;
    }

    public void onLevelSelected(View view) {
        int levelId;

        if(easy.isChecked())
        {
            levelId = R.string.easyMode;
        }
        else if(med.isChecked())
        {
            levelId = R.string.mediumMode;
        }
        else if(hard.isChecked())
        {
            levelId = R.string.hardMode;
        }
        else
        {
            levelId = R.string.easyMode;
        }
        // Save selected level ID in SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(LEVEL_PREFERENCE, levelId);
        editor.apply();

    }
}