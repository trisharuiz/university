package com.example.connectfour;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Instantiate views
        BottomNavigationView navView = findViewById(R.id.nav_view);
        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);

        if (navHostFragment != null) {
            NavController navController = navHostFragment.getNavController();

            AppBarConfiguration appBarConfig = new AppBarConfiguration.Builder(
                    R.id.menu_connect_four, R.id.menu_options) // this is the two items in nav_graph
                    .build();

            NavigationUI.setupActionBarWithNavController(this, navController, appBarConfig);
            NavigationUI.setupWithNavController(navView, navController);
        }
    }
    /*
    public void onBoardClick(View view) {
        Intent intent = new Intent(this, BoardFragment.class);
        startActivity(intent);
    }

    public void onOptionsClick(View view) {
        Intent intent = new Intent(this, GameOptionsFragment.class);
        mModeResultLauncher.launch(intent);
    }

    ActivityResultLauncher<Intent> mModeResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            int level = data.getIntExtra(GameOptionsFragment.GAME_MODE, R.string.easyMode);

                            if (level == R.string.easyMode) {
                                Toast.makeText(getApplicationContext(), "Easy Mode", Toast.LENGTH_LONG).show();
                            }
                            else if (level == R.string.mediumMode) {
                                Toast.makeText(getApplicationContext(), "Medium Mode", Toast.LENGTH_LONG).show();
                            }
                            else if (level == R.string.hardMode) {
                                Toast.makeText(getApplicationContext(), "Hard Mode", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                }
            });

     */

}