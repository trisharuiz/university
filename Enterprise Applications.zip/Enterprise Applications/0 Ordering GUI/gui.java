/* Name: Trisha Esther Ruiz
 Course: CNT 4714 – Spring 2023
 Assignment title: Project 1 – Event-driven Enterprise Simulation
 Date: Sunday January 29, 2023
*/

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.*;

class item {
	String ID;
	String name;
	String stock;
	double price;
	String[] details = new String[4];
	
	public item(String details) {
		this.details = details.split(",");
		
		this.ID = this.details[0].trim();
		this.name = this.details[1].trim();
		this.stock = this.details[2].trim();
		this.price = Double.parseDouble(this.details[3].trim());
	}
	public String getID() {
		return ID;
	}
	public String getName() {
		return name;
	}
	public String getStock() {
		return stock;
	}
	public double getPrice() {
		return price;
	}
	public void print() {
		System.out.println(ID+","+name+","+stock+","+price);
	}
	public String getDetails() {
		return ID+" "+name+" $"+String.format("%.2f",price); 
	}
	public String getDetails(boolean transaction) {
		return ID+", "+name+", "+String.format("%.2f",price); 
	}
	
}

public class gui extends JFrame implements ActionListener {

	// initialize components
	int num = 1;
	int total = 0;
	double subtotal = 0;
	double discount = 0;
	double discountedTotal = 0;
	String details = "";
	String detailsTransaction = "";
	String currOrder = "";
	String currOrderTransaction = "";
	ArrayList<String> currOrderList = new ArrayList<String>();
	
	JPanel infoPanel = new JPanel();
	JPanel buttonPanel = new JPanel();
	
	JButton find = new JButton("Find Item #"+num);
	JButton purchase = new JButton("Purchase Item #"+num);
	JButton current = new JButton("View Current Order");
	JButton complete = new JButton("Complete Order - Check Out");
	JButton newOrder = new JButton("Start New Order");
	JButton exit = new JButton("Exit(Close App)");
	
	
	JLabel idLabel = new JLabel("Enter item ID for Item #"+num+":", JLabel.RIGHT);
	JLabel quantityLabel = new JLabel("Enter quanitity for Item #"+num+":", JLabel.RIGHT);
	JLabel detailLabel = new JLabel("Details for Item #"+num+":", JLabel.RIGHT);
	JLabel subtotalLabel = new JLabel("Order subtotal for "+total+" item(s):", JLabel.RIGHT);

	JTextField textField = new JTextField(100);
	JTextField textField2 = new JTextField(100);
	JTextField textField3 = new JTextField(100);
	JTextField textField4 = new JTextField(100);
	
	//constructor
	public gui(FileWriter transaction) {

		// init gui
		super("Nile Dot Com");
		setBackground(Color.BLUE);
		setBounds(0, 0, 700, 450);
		setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		add(buttonPanel);
		add(infoPanel);

		// build button panels
		buttonPanel.setBounds(40,220, 600, 150);
		buttonPanel.setLayout(new GridLayout(3,2, 100, 20));
		
		buttonPanel.add(find);
		buttonPanel.add(purchase);
		buttonPanel.add(current);
		buttonPanel.add(complete);
		buttonPanel.add(newOrder);
		buttonPanel.add(exit);
		
		//build info panels and boxes
		infoPanel.setBounds(-200, 40, 800, 160);
		infoPanel.setLayout(new GridLayout(4, 2, 10, 10));
		
		
		infoPanel.add(idLabel);
		infoPanel.add(textField);

		infoPanel.add(quantityLabel);
		infoPanel.add(textField2);
		
		infoPanel.add(detailLabel);
		textField3.setEditable(false);
		textField3.setBackground(Color.white);
		infoPanel.add(textField3);
		
		infoPanel.add(subtotalLabel);
		textField4.setEditable(false);
		textField4.setBackground(Color.white);
		infoPanel.add(textField4);
		
		// build buttons
		find.addActionListener(this);
		purchase.addActionListener(this);
		newOrder.addActionListener(this);
		exit.addActionListener(this);
		current.addActionListener(this);
		
		complete.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent arg0) {
				//get time stamp
	        	 LocalDateTime localTime = LocalDateTime.now();
	        	 DateTimeFormatter formatTime = DateTimeFormatter.ofPattern("MM/DD/YY, hh:mm:ss a");
	        	 String timeStamp = localTime.format(formatTime)+ " EST";
	        	
	        	 //System.out.println(timeStamp);

				//get permutation id based on DDMMYYYYHHMM
				String transactionID = new SimpleDateFormat("DDMMYYYYHHmm").format(new java.util.Date());
				//System.out.println(transactionID);
				
				//get tax
				double taxRate = .06;
				double taxAmount = subtotal * taxRate;
				double total = subtotal + taxAmount;
				
				// display information
				String finalInvoice = "";
				
				finalInvoice += "Date: "+timeStamp+"\n";
				finalInvoice += "\nNumber of line items: "+(num-1)+"\n";
				finalInvoice += "\nItem# / ID / Title / Price / Qty / Disc % / Subtotal:\n";
				finalInvoice += "\n"+currOrder+"\n";
				finalInvoice += "\nOrder subtotal:    $"+String.format("%.2f", subtotal)+"\n";
				finalInvoice += "\nTax rate:    "+(int)(taxRate*100)+"%\n";
				finalInvoice += "\nTax amount:    $"+String.format("%.2f", taxAmount)+"\n";
				finalInvoice += "\nORDER TOTAL:    $"+String.format("%.2f", total)+"\n";
				finalInvoice += "\nThanks for shopping at Nile Dot Com!";
				
				JOptionPane.showMessageDialog(null, finalInvoice, "Nile Dot Com - FINAL INVOICE", JOptionPane.INFORMATION_MESSAGE);
				
				//write to transactions
				try {
					currOrderList.forEach(e -> currOrderTransaction += transactionID+", "+e+", "+timeStamp+"\n");
					//System.out.println(currOrderTransaction);
					transaction.append(currOrderTransaction);
					transaction.flush();
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//disable find, purchase, complete, textField, TextField 2
				find.setEnabled(false);
				purchase.setEnabled(false);
				complete.setEnabled(false);
				textField.setEnabled(false);
				textField2.setEnabled(false);
	        }
		});
		
		//turn off other buttons
		purchase.setEnabled(false);
		current.setEnabled(false);
		complete.setEnabled(false);
		
		
		setVisible(true); // display this frame
	}

	public static void main(String args[]) throws Exception {
		FileWriter transaction = new FileWriter("transactions.txt", true);
		
		gui gui = new gui(transaction);
		
		
	}
	
	//will check if item is in inventory
	private static item checkItem(String ID) throws FileNotFoundException {
		
		//reads file
		File file = new File("inventory.txt");
		Scanner scan = new Scanner(file);
		
		//init item and string
		String detail = "";
		item i = null;
		
		//searches file
		while(scan.hasNextLine()) {
			detail = scan.nextLine();
			i = new item(detail);
			
			//checks for matches in ID
			if(ID.equals(i.getID())) {
				return i;
			}
			
		}
		
		//if not in file registers item as not in stuck or null
		i = new item(" , ,false,0");
		return null;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		Object button = e.getSource();
		
		if(button == find) {
			
			try {
				
				//init item and quantity
				item i = new item(" , ,false,0");
				int quantity = 0;
				
				//check if fields are filled out properly then check if item is in list
				if(!textField.getText().isEmpty() && !textField2.getText().isEmpty()) {
					i = checkItem(textField.getText());
					quantity = Integer.parseInt(textField2.getText());
				}else {
					return;
				}
				
				//handles not in file and out of stock
				if (i == null) {
					//System.out.println("NO FILE");
					JOptionPane.showMessageDialog(null, "item ID "+textField.getText()+" not in file", "Nile Dot Com - ERROR", JOptionPane.WARNING_MESSAGE);
					setVisible(true);
					
					//clear textFields
					textField.setText("");
					textField2.setText("");
			
				}else if(i.getStock().equals("false")) {
					//System.out.println("OUT OF STOCK");
					JOptionPane.showMessageDialog(null, "Sorry... that item is out of stock, please try another item", "Nile Dot Com - ERROR", JOptionPane.WARNING_MESSAGE);
					setVisible(true);
					
					//clear textFields
					textField.setText("");
					textField2.setText("");
				}
				//handles if in file or in stock
				else {
					//i.print();
					//System.out.println("FOUND IT");
					
					//update detailsLabel
					detailLabel.setText("Details for Item #"+num+":");
					
					//change buttons
					purchase.setEnabled(true);
					find.setEnabled(false);
					
					//update textFields
					textField.setEditable(false);
					textField2.setEditable(false);
					textField.setBackground(Color.white);
					textField2.setBackground(Color.white);

					
					//get discount
					if(quantity >= 1 && quantity <= 4) {
						discount = 0;
					}else if(quantity >= 5 && quantity <= 9) {
						discount = .10;
					}else if(quantity >= 10 && quantity <= 14) {
						discount = .15;
					}else if(quantity >= 15) {
						discount = .20;
					}
					double totalWithout = quantity  * i.getPrice();
					discountedTotal = totalWithout - (discount*totalWithout);
					
					
					//show details
					details = i.getDetails()+" "+quantity+" %"+(int)(discount*100)+" $"+String.format("%.2f", discountedTotal);
					detailsTransaction = i.getDetails(true)+", "+quantity+", "+discount+", $"+String.format("%.2f", discountedTotal);
					textField3.setText(details);
					
				}
				
				
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			
		}else if(button == purchase) {
			
			//window popup
			JOptionPane.showMessageDialog(null, "Item #"+num+" accepted. Added to your cart.", "Nile Dot Com - Item Confirmed", JOptionPane.PLAIN_MESSAGE);
			setVisible(true);
			
			//update current order
			currOrder += num+"."+details+"\n";
			currOrderList.add(detailsTransaction);
			//System.out.println(currOrder);
			
			//update info
			num += 1;
			idLabel.setText("Enter item ID for Item #"+num+":");
			quantityLabel.setText("Enter quanitity for Item #"+num+":"); 
			
			find.setText("Find Item #"+num);
			purchase.setText("Purchase Item #"+num);
			
			subtotal += discountedTotal;
			textField4.setText("$"+String.format("%.2f", subtotal));
			
			//update textFields
			textField.setText("");
			textField2.setText("");
			textField.setEditable(true);
			textField2.setEditable(true);
			textField.setBackground(Color.white);
			textField2.setBackground(Color.white);
			
			//update buttons
			current.setEnabled(true);
			complete.setEnabled(true);
			find.setEnabled(true);
			purchase.setEnabled(false);
			
			
		}else if(button == current) {
			
			//show current order
			JOptionPane.showMessageDialog(null, currOrder, "Message Dialog", JOptionPane.INFORMATION_MESSAGE);
			setVisible(true);
			
			
		}else if(button == newOrder) {
			//init vars
			currOrder = "";
			total = 0;
			subtotal = 0;
			discount = 0;
			discountedTotal = 0;
			details = "";
			
			//init transaction values
			detailsTransaction = "";
			currOrder = "";
			currOrderList.clear();
			currOrderTransaction = "";
			
			//init number values
			num = 1;
			idLabel.setText("Enter item ID for Item #"+num+":");
			quantityLabel.setText("Enter quanitity for Item #"+num+":"); 
			detailLabel.setText("Details for Item #"+num+":");
			find.setText("Find Item #"+num);
			purchase.setText("Purchase Item #"+num);
			
			//init enabled buttons
			find.setEnabled(true);
			current.setEnabled(false);
			
			//init textFields
			textField.setEnabled(true);
			textField2.setEnabled(true);
			textField.setEditable(true);
			textField2.setEditable(true);
			textField.setText("");
			textField2.setText("");
			textField3.setText("");
			textField4.setText("");
			
		}else if(button == exit) {
			//init vars
			currOrder = "";
			total = 0;
			subtotal = 0;
			discount = 0;
			discountedTotal = 0;
			details = "";
			
			//init transaction values
			detailsTransaction = "";
			currOrder = "";
			currOrderList.clear();
			currOrderTransaction = "";
			
			//init number values
			num = 1;
			idLabel.setText("Enter item ID for Item #"+num+":");
			quantityLabel.setText("Enter quanitity for Item #"+num+":"); 
			detailLabel.setText("Details for Item #"+num+":");
			find.setText("Find Item #"+num);
			purchase.setText("Purchase Item #"+num);
			
			//init enabled buttons
			find.setEnabled(true);
			current.setEnabled(false);
			
			//init textFields
			textField.setEnabled(true);
			textField2.setEnabled(true);
			textField.setText("");
			textField2.setText("");
			textField3.setText("");
			textField4.setText("");
			
			System.exit(0);
			
		}
	}
}

