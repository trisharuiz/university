/* Name: Trisha Esther Ruiz
Course: CNT 4714 Spring 2023
Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
Due Date: February 12, 2023
*/


import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class ABankingSimulator {
	
	public static void main(String[] args) throws IOException{
		BankAccount account = new BankAccount();
		FileWriter transaction = new FileWriter("transactions.txt", true);

		
	   // create new thread pool with two threads
	   ExecutorService application = Executors.newFixedThreadPool(16);
	   System.out.printf("%s\t\t\t%s\t\t\t%s\t\t\t\t\t\t%s", "Deposit Agents", "Withdrawal Agents", "Balance", "Transaction Number");
	   System.out.printf("\n%s\t\t\t%s\t\t\t%s\t\t\t\t\t\t%s", "--------------", "-----------------", "-------", "------------------");
	   
	   // create SynchronizedBuffer to store ints
	   try 
	   {
		   
		   application.execute(new Withdrawer(account, "Agent WT1", transaction));
		   application.execute(new Withdrawer(account, "Agent WT2", transaction));
		   application.execute(new Withdrawer(account, "Agent WT3", transaction));
		   application.execute(new Depositor1(account, "Agent DT1", transaction));
		   
		   application.execute(new Withdrawer(account, "Agent WT4", transaction));
		   application.execute(new Withdrawer(account, "Agent WT5", transaction));
		   application.execute(new Withdrawer(account, "Agent WT6", transaction));
		   application.execute(new Depositor1(account, "Agent DT2", transaction));
		   
		   application.execute(new Withdrawer(account, "Agent WT7", transaction));
		   application.execute(new Withdrawer(account, "Agent WT8", transaction));
		   application.execute(new Withdrawer(account, "Agent WT9", transaction));
		   application.execute(new Depositor1(account, "Agent DT3", transaction));
		   
		   application.execute(new Withdrawer(account, "Agent WT10", transaction));		   
		   application.execute(new Depositor1(account, "Agent DT4", transaction));
		   application.execute(new Depositor1(account, "Agent DT5", transaction));
		   application.execute(new Auditor(account, "Auditor"));



		
	   }
	   catch ( Exception exception )
	   {
	      exception.printStackTrace();
	   } // end catch
	   
	   application.shutdown();
	} // end main
}
