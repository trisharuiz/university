/* Name: Trisha Esther Ruiz
Course: CNT 4714 Spring 2023
Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
Due Date: February 12, 2023
*/


import java.util.Random;

public class Auditor implements Runnable{
	
	private BankAccount account;
	private int money;
	private String name;
	private static Random generator = new Random();
	private boolean initialized = false;

	
	public Auditor(BankAccount account, String name) {
		this.account = account;
		this.money = generator.nextInt(1, 500);
		this.name = name;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			//while true
			while(true) {
				if(initialized) {
					account.audit();
					//account.deposit(1, name);
					int time = generator.nextInt(3000, 7000);
					//System.out.println("deposit "+time);
					Thread.sleep(time);
				}else {
					initialized = true;
				}
		}
		}
		catch(InterruptedException exception) {}
		
	}

}
