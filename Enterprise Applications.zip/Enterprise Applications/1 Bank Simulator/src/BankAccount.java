/* Name: Trisha Esther Ruiz
Course: CNT 4714 Spring 2023
Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
Due Date: February 12, 2023
*/

import java.util.concurrent.locks.Condition;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class BankAccount {
	private int balance;
	private Lock accessBalanceLock;
	private Condition hasFunds;
	private int count;
	private int countSince;
	
	//constructor
	public BankAccount() {
		balance = 10;
		accessBalanceLock = new ReentrantLock();
		hasFunds = accessBalanceLock.newCondition();
		count = 0;
		countSince = 0;
	}
	
	public void deposit(int money, String name, FileWriter transaction) throws IOException {
		accessBalanceLock.lock();
		try {
			
			int updatedBalance = balance + money;
			balance = updatedBalance;
			count += 1;
			countSince += 1;
			System.out.printf("\n%s\t\t%s\t\t\t\t\t%s\t\t\t\t\t%s", name+" deposits $"+money, "", "(+) Balance is $"+balance, count);
			
			if(money > 350) {
				LocalDateTime localTime = LocalDateTime.now();
				DateTimeFormatter formatTime = DateTimeFormatter.ofPattern("MM/DD/YY, hh:mm:ss a");
				String timeStamp = localTime.format(formatTime)+ " EST";
				
				System.out.printf("\n* * * Flagged Transaction - Depositor Agent %s Made A Deposit In Excess Of $350.00 USD - See Flagged Transaction Log.\n", name);
				transaction.append("\nDepositor Agent "+name+" issued deposit of $"+money+" at: "+timeStamp+"\tTransaction Number : "+count);
				transaction.flush();
			}
			
			hasFunds.signalAll();
		}
		finally {
			accessBalanceLock.unlock();
		}
	}
	public void withdraw(int money, String name, FileWriter transaction) throws InterruptedException, IOException {
		accessBalanceLock.lock();
		try {
			while(balance < money) {
				hasFunds.await();
				System.out.printf("\n%s\t\t\t\t%s\t\t\t%s", "", name+" withdraws $"+money, "(****) WITHDRAWAL BLOCKED - INSUFFICIENT FUNDS");
			}
			
			
			int updatedBalance = balance - money;
			balance = updatedBalance;
			count += 1;
			countSince += 1;
			if(name.equals("Agent WT10")) {
				System.out.printf("\n%s\t\t\t\t%s\t\t%s\t\t\t\t\t%s", "", name+" withdraws  $"+money, "(-) Balance is $"+balance, count);
				
			}else {
				System.out.printf("\n%s\t\t\t\t%s\t\t\t%s\t\t\t\t\t%s", "", name+" withdraws $"+money, "(-) Balance is $"+balance, count);

			}
			if(money > 75) {
				LocalDateTime localTime = LocalDateTime.now();
				DateTimeFormatter formatTime = DateTimeFormatter.ofPattern("MM/DD/YY, hh:mm:ss a");
				String timeStamp = localTime.format(formatTime)+ " EST";
				
				System.out.printf("\n* * * Flagged Transaction - Withdrawal Agent %s Made A Deposit In Excess Of $75.00 USD - See Flagged Transaction Log.\n", name);
				transaction.append("\n\tWithdrawal Agent "+name+" issued deposit of $"+money+" at: "+timeStamp+"\tTransaction Number : "+count);
				transaction.flush();
			}
			
		}
		finally {
			accessBalanceLock.unlock();
		}
	}
	public void audit() throws InterruptedException {
		accessBalanceLock.lock();

		try {
			System.out.printf("\n\n***********************************************************************************************************\n");
			System.out.printf("\n\tAUDITOR FINDS CURRENT BALANCE TO BE:\t$%s\tNumber of transactions since last audit is: %s\n",balance, countSince);
			countSince = 0;
			System.out.printf("\n***********************************************************************************************************\n\n");
		}finally{
			accessBalanceLock.unlock();
		}
	}
	public int getBalance() {
		return balance;
	}
}
