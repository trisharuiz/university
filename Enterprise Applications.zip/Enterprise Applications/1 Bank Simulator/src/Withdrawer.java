/* Name: Trisha Esther Ruiz
Course: CNT 4714 Spring 2023
Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
Due Date: February 12, 2023
*/

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class Withdrawer implements Runnable{
	
	private BankAccount account;
	private int money;
	private static Random generator = new Random();
	private String name;
	private boolean initialized = false;
	FileWriter transaction;

	
	public Withdrawer(BankAccount account, String name, FileWriter transaction) {
		this.account = account;
		this.money = generator.nextInt(1, 500);
		this.name = name;
		this.transaction = transaction;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			//while true
				while(true) {
					if(initialized) {
						this.money = generator.nextInt(1, 99);
						account.withdraw(money, name, transaction);
						//account.withdraw(1, name);
						int time = generator.nextInt(2000);
						//System.out.println("withdraw "+time);
						Thread.sleep(time);
					}else {
						initialized = true;
					}
				}

		}
		catch(InterruptedException | IOException exception) {}
		
	}

}
