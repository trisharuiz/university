
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import javax.swing.table.AbstractTableModel;
import java.util.Properties;

public class ResultSetTableModel extends AbstractTableModel {
	
	private Connection connection;
	private Statement statement;
	private ResultSet resultSet;
	private ResultSetMetaData metaData;
	private int numberOfRows;
	private Properties properties;
	private boolean connectedToDatabase = false;

	public ResultSetTableModel(String query, Connection connect) throws SQLException, ClassNotFoundException {
		try {
			
			//take connection made from gui
			Connection connection = connect;
			statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			connectedToDatabase = true;
			setQuery(query);

		} 
		catch (SQLException sqlException) {
			sqlException.printStackTrace();
			System.exit(1);
		} 
	} 

// create Columns
	public Class getColumnClass(int column) throws IllegalStateException {
	
		if (!connectedToDatabase)
			throw new IllegalStateException("Not Connected to Database");

		try {
			String className = metaData.getColumnClassName(column + 1);
			return Class.forName(className);
		} 
		catch (Exception exception) {
			exception.printStackTrace();
		} 
		return Object.class; 
	} 

// get column count
	public int getColumnCount() throws IllegalStateException {
		
		if (!connectedToDatabase)
			throw new IllegalStateException("Not Connected to Database");
		try {
			return metaData.getColumnCount();
		}
		catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}
		return 0; 
	} 

// get column name
	public String getColumnName(int column) throws IllegalStateException {
		
		if (!connectedToDatabase)
			throw new IllegalStateException("Not Connected to Database");
		try {
			return metaData.getColumnName(column + 1);
		} 
		catch (SQLException sqlException) {
			sqlException.printStackTrace();
		} 
		return ""; 
	} 

// return row count
	public int getRowCount() throws IllegalStateException {

		if (!connectedToDatabase)
			throw new IllegalStateException("Not Connected to Database");
		return numberOfRows;
	} 
//get value in from [row][col]
	public Object getValueAt(int row, int column) throws IllegalStateException {
		
		if (!connectedToDatabase)
			throw new IllegalStateException("Not Connected to Database");
		try {
			resultSet.next(); 
			resultSet.absolute(row + 1);
			return resultSet.getObject(column + 1);
		} 
		catch (SQLException sqlException) {
			sqlException.printStackTrace();
		} 
		return ""; 
	} 
//exec queries only
	public void setQuery(String query) throws SQLException, IllegalStateException {
		if (!connectedToDatabase)
			throw new IllegalStateException("Not Connected to Database");

		resultSet = statement.executeQuery(query);
		metaData = resultSet.getMetaData();
		resultSet.last(); 
		numberOfRows = resultSet.getRow();

		fireTableStructureChanged();
	}

//exec update only
	public int setUpdate(String query) throws SQLException, IllegalStateException {
		int rowsAffected;
		
		if (!connectedToDatabase)
			throw new IllegalStateException("Not Connected to Database");

		rowsAffected = statement.executeUpdate(query);

		fireTableStructureChanged();
		return rowsAffected;
	}

// close Statement and Connection
	public void disconnectFromDatabase() {
		if (!connectedToDatabase)
			return;
		else
			try {
				statement.close();
				connection.close();
			}
			catch (SQLException sqlException) {
				sqlException.printStackTrace();
			}
			finally 
			{
				connectedToDatabase = false;
			} 
	}
	public boolean getStatus() {
		return connectedToDatabase;
	}

	public String getURL() {
		return properties.getProperty("MYSQL_DB_URL");
	}
}
