/*
Name: Trisha Esther Ruiz
Course: CNT 4714 Spring 2023
Assignment title: Project 3 – A Two-tier Client-Server Application
Date: March 9, 2023
Class:  CNT4714-23Spring 0001 
*/
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

import com.mysql.cj.jdbc.MysqlDataSource;

public class guiClientApp extends JFrame{
	
	//make different areas;
	private JPanel connectionArea;
	private JPanel commandArea;
	private JPanel resultArea;
	
	//make labels
	private JLabel propLab;
	private JLabel userLab;
	private JLabel passLab;
	private JLabel connectT;
	private JLabel commandT;
	private JLabel resultT;

	
	//textField
	private JTextField userField;
	private JTextField passField;
	private JTextField connectionLab;
	private JPanel tableLab;
	
	

	
	private JComboBox propList;
	
	//button
	private JButton connectButt;
	private JButton execButt;
	private JButton clearResButt;
	private JButton clearCommButt;

	//database things
	static final String DEFAULT_QUERY = "SELECT * FROM riders";
	private ResultSetTableModel tableModel;
	private JTextArea commandField;	
    JTable resultTable;
    JScrollPane scrollPane = null;
    
    private Properties properties;
	FileInputStream filein = null;
	MysqlDataSource dataSource = null;
	   
    
	String user = "";
	String username = "";
	String password = "";
	
	Connection connection = null;
	Connection connect = null;
	
	Statement statement = null;
	ResultSet resultSet = null;
	int affectedRows = 0;
	
	public guiClientApp() throws IOException, SQLException {
		super("SQL Client App - (TETR - CNT 4714 - Spring 2023 - Project 3");
	
		//init GUI
		setBounds(100, 100, 800, 800);
		setBackground(Color.white);
		setLayout(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		//BUILD connectionArea
		connectionArea = new JPanel(null);
		connectionArea.setBounds(0, 0, 400, 300);
		connectionArea.setBackground(Color.YELLOW);
		
		
		//label
		connectT = new JLabel("Connection Details");
		propLab = new JLabel("Properties File");
		userLab = new JLabel("Username");
		passLab = new JLabel("Password");
		connectT.setBounds(10, 10, 200, 40);
		propLab.setBounds(10, 50, 120, 40);
		userLab.setBounds(10, 100, 120, 40);
		passLab.setBounds(10, 150, 120, 40);
		propLab.setOpaque(true);
		userLab.setOpaque(true);
		passLab.setOpaque(true);
		propLab.setBackground(Color.lightGray);
		userLab.setBackground(Color.lightGray);
		passLab.setBackground(Color.lightGray);
		connectT.setForeground(Color.BLUE);
		connectionArea.add(connectT);
		connectionArea.add(propLab);
		connectionArea.add(userLab);
		connectionArea.add(passLab);
		
		//textField + dropdown = button
		String[] listProp = {"client.properties", "root.properties"};
		propList = new JComboBox(listProp);
		userField = new JTextField();
		passField = new JPasswordField();
		connectButt = new JButton("Connect to Database");
		
		propList.setBounds(140, 50, 250, 40);
		userField.setBounds(140, 100, 250, 40);
		passField.setBounds(140, 150, 250, 40);
		connectButt.setBounds(15, 200, 250, 30);
		connectButt.setBackground(Color.blue);
		connectButt.setForeground(Color.yellow);
		
		connectionArea.add(propList);
		connectionArea.add(userField);
		connectionArea.add(passField);
		connectionArea.add(connectButt);
		
		add(connectionArea);
		
		//BUILD commandArea
		commandArea = new JPanel(null);
		commandArea.setBounds(400, 0, 400, 300);
		commandArea.setBackground(Color.pink);
		
		//label
		commandT = new JLabel("Enter An SQL Command");
		commandT.setBounds(10, 10, 200, 40);
		commandT.setForeground(Color.blue);
		commandArea.add(commandT);

		//field
		commandField = new JTextArea();
		commandField.setText("PLEASE LOG IN FIRST");
		commandField.setDisabledTextColor(Color.red);
		commandField.setEnabled(false);
		commandField.setLineWrap(true);
		commandField.setWrapStyleWord(true);
		
        JScrollPane textScroll = new JScrollPane( commandField,
        ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, 
        ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER );
		textScroll.setBounds(10, 40, 350, 200);
		commandArea.add(textScroll);
		
		//buttons
		clearCommButt = new JButton("Clear SQL Command");
		execButt = new JButton("Execute SQL Command");
		clearCommButt.setBounds(10, 250, 175, 30);
		execButt.setBounds(190, 250, 195, 30);
		clearCommButt.setForeground(Color.red);
		clearCommButt.setBackground(Color.white);
		execButt.setBackground(Color.green);
		clearCommButt.setEnabled(false);
		execButt.setEnabled(false);
		
		commandArea.add(clearCommButt);
		commandArea.add(execButt);
		
		add(commandArea);
		
		//BUILD resultArea
		resultArea = new JPanel(null);
		resultArea.setBounds(0, 300, 800, 500);
		resultArea.setBackground(Color.cyan);
		
		//label
		resultT = new JLabel("SQL Execution Result Window");
		resultT.setBounds(10, 55, 250, 40);
		resultT.setForeground(Color.BLUE);
		resultArea.add(resultT);

		//clear result window
		clearResButt = new JButton("Clear Result Window");
		clearResButt.setBackground(Color.yellow);
		clearResButt.setBounds(15, 400, 200, 30);
		resultArea.add(clearResButt);
		
		//connection status box
		connectionLab = new JTextField("NO CONNECTION NOW");
		connectionLab.setDisabledTextColor(Color.RED);
		connectionLab.setEnabled(false);
		connectionLab.setBounds(15, 5, 700, 40);
		connectionLab.setForeground(Color.yellow);
		connectionLab.setBackground(Color.black);
		resultArea.add(connectionLab);
		
		//connection status box
		tableLab = new JPanel(null);
		tableLab.setBackground(Color.white);
		tableLab.setBounds(15, 100, 750, 280);
		resultArea.add(tableLab);
		
		//table							
		resultTable = new JTable(tableModel);	
	    scrollPane = new JScrollPane(resultTable);
	    scrollPane.setEnabled(true);    
	    scrollPane.setBounds(15, 100, 750, 280);
	    resultArea.add(scrollPane);
    	
		add(resultArea);
		
		execButt.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {					
						
						//do the query
						try {
							
							String command = commandField.getText();
					
							//update project3
						    if(command.toLowerCase().contains("delete") || command.toLowerCase().contains("update") || command.toLowerCase().contains("insert") ) {
						    	affectedRows = tableModel.setUpdate(command);
		                        JOptionPane.showMessageDialog( null, 
		 	                           "Successful Update..."+affectedRows+" rows updated.", "Successful Update", 
		 	                           JOptionPane.INFORMATION_MESSAGE);
						    	
						    }else {
			                    tableModel.setQuery(command);
								//System.out.println("Creating Table");
								resultArea.remove(scrollPane);
								
								resultTable = new JTable(tableModel);
							    scrollPane = new JScrollPane(resultTable);
							    
							    scrollPane.setBounds(15, 100, 750, 280);
							    resultArea.add(scrollPane);
						    }
							


						    // update operations log
						    statement = connect.createStatement();
						    
						    
						    if(command.toLowerCase().contains("delete") || command.toLowerCase().contains("update") || command.toLowerCase().contains("insert") ) {
						    	//System.out.println("updating updates");
						    	statement.executeUpdate("UPDATE operationscount set num_updates = num_updates + 1;");
						    }else {
						    	//System.out.println("update queries");
						    	statement.executeUpdate("UPDATE operationscount set num_queries = num_queries + 1;");
						    }
							
						} catch ( SQLException sqlException ) 
		                  {
	                     JOptionPane.showMessageDialog( null, 
	                        sqlException.getMessage(), "Database error", 
	                        JOptionPane.ERROR_MESSAGE );
	                     
	                     // try to recover from invalid user query 
	                     // by executing default query
	                     try 
	                     {
	                        tableModel.setQuery( DEFAULT_QUERY );
	                        commandField.setText( DEFAULT_QUERY );
	                     } // end try
	                     catch ( SQLException sqlException2 ) 
	                     {
	                        JOptionPane.showMessageDialog( null, 
	                           sqlException2.getMessage(), "Database error", 
	                           JOptionPane.ERROR_MESSAGE );
	         
	                        // ensure database connection is closed
	                        tableModel.disconnectFromDatabase();
	         
	                        System.exit( 1 ); // terminate application
	                     } // end inner catch                   
	                  } // end outer catch
					}
				}
				);//END OF EXEC
		
		connectButt.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						

						
						//take what user is trying to login
						user = propList.getSelectedItem().toString();
						username = userField.getText();
						password = passField.getText();
						
				    	
						//make a connection
						try {
							//connect to project3
							connection = getConnection(user, false);
							
							//connect to operations
						    connect = getConnection(user, true);

						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

						
						//if fields are empty
						if(username.isEmpty() || password.isEmpty()) {
					         JOptionPane.showMessageDialog( null, 
							            "Please Enter Correct Username or Password", "Try Again",
							            JOptionPane.ERROR_MESSAGE );
					         try {
								connection.close();
							} catch (SQLException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
						//if fields don't match
						else if(!username.equals(properties.getProperty("MYSQL_DB_USERNAME")) || !password.equals(properties.getProperty("MYSQL_DB_PASSWORD")) || !user.substring(0, user.indexOf(".")).equals(properties.getProperty("MYSQL_DB_USERNAME"))){
								connectionLab.setText("NOT CONNECTED - User Credentials Do Not Match Properties File");
								connectionLab.setDisabledTextColor(Color.red);
					         try {
								connection.close();
							} catch (SQLException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
						//if everything matches
						else {
							//try to connect to database
							try {
								tableModel = new ResultSetTableModel(DEFAULT_QUERY, connection);
								
								//once connected
								if(tableModel.getStatus() == true) {
									//then set connection status
									connectionLab.setText("CONNECTED TO: "+ properties.getProperty("MYSQL_DB_URL"));
									connectionLab.setDisabledTextColor(Color.YELLOW);
									
									//then set commandField elements to enabled
									commandField.setEnabled(true);
									execButt.setEnabled(true);
									clearCommButt.setEnabled(true);
									commandField.setText("");
									
								}
								
							} catch ( ClassNotFoundException classNotFound ) 
						      {
						         JOptionPane.showMessageDialog( null, 
						            "MySQL driver not found", "Driver not found",
						            JOptionPane.ERROR_MESSAGE );
						         
						         System.exit( 1 ); // terminate application
						      } // end catch
						      catch ( SQLException sqlException ) 
						      {
						         JOptionPane.showMessageDialog( null, sqlException.getMessage(), 
						            "Database error", JOptionPane.ERROR_MESSAGE );
						               
						         // ensure database connection is closed
						         tableModel.disconnectFromDatabase();
						         
						         System.exit( 1 );   // terminate application
						      } // end catch
						}
						
						
						
						
					      
					}
				}
				);
		
		clearResButt.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
					    scrollPane.repaint();
					    resultArea.repaint();
					    resultTable.repaint();
						resultArea.remove(scrollPane);

					}
				}
				);
		
		clearCommButt.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						commandField.setText("");
					}
				}
				);
		
		
		
		setVisible(true); // display this frame
		
	}
	private Connection getConnection(String user, Boolean isOperations) throws IOException, SQLException {
		//database stuff
		Connection holder = null;
		
		if(isOperations == false) {
			System.out.println("connecting to project3");
	    	filein = new FileInputStream(user);
	    	
			properties = new Properties();
	    	properties.load(filein);
	    	dataSource = new MysqlDataSource();
	    	dataSource.setURL(properties.getProperty("MYSQL_DB_URL"));
	    	dataSource.setUser(properties.getProperty("MYSQL_DB_USERNAME"));
	    	dataSource.setPassword(properties.getProperty("MYSQL_DB_PASSWORD")); 	
	    	holder = dataSource.getConnection();
	    	
	    	return holder;
		}else {
			//System.out.println("connecting to operations");
			filein = new FileInputStream("root.properties");
			
			Properties property = new Properties();
	    	property.load(filein);
	    	MysqlDataSource data = new MysqlDataSource();
	    	data.setURL("jdbc:mysql://localhost:3306/operationslog");
	    	data.setUser(property.getProperty("MYSQL_DB_USERNAME"));
	    	data.setPassword(property.getProperty("MYSQL_DB_PASSWORD")); 	
	    	holder = data.getConnection();
	    	
	    	return holder;
		}


	}
	public static void main(String args[])throws Exception{
		
		guiClientApp clientApp = new guiClientApp();
		
	}
	
}
