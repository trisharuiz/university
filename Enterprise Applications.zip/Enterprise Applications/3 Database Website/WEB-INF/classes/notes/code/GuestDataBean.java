package notes.code;

import javax.sql.rowset.*;

import java.sql.Connection;
import java.sql.SQLException;
import com.mysql.cj.jdbc.MysqlDataSource;
import java.util.ArrayList;

public class GuestDataBean {

	private CachedRowSet rowSet;
	MysqlDataSource dataSource = null;
   	Connection connection = null;

	
	public GuestDataBean() throws Exception
	{
		Class.forName("com.mysql.jdbc.Driver");
		dataSource = new MysqlDataSource();
		
		rowSet = RowSetProvider.newFactory().createCachedRowSet();
		rowSet.setUrl("jdbc:mysql://localhost:3306/guestbook");
		rowSet.setUsername("root");
		rowSet.setPassword("trisharon17");
		
		dataSource.setUrl("jdbc:mysql://localhost:3306/guestbook");
		dataSource.setUser("root");
		dataSource.setPassword("trisharon17");

		
		rowSet.setCommand("SELECT firstName, lastName, email FROM guests");
		rowSet.execute();
		
       	connection = dataSource.getConnection();
		
	}
	
public ArrayList<GuestBean> getGuestList() throws SQLException
{
	ArrayList<GuestBean> guestList = new ArrayList<GuestBean>();
	
	rowSet.beforeFirst();
	
	while(rowSet.next()) {
		GuestBean guest = new GuestBean();
		
		guest.setFirstName(rowSet.getString(1));
		guest.setLastName(rowSet.getString(2));
		guest.setEmail(rowSet.getString(3));
		
		guestList.add(guest);

	}
	
	return guestList;
}

public void addGuest(GuestBean guest) throws SQLException
{
	rowSet.moveToInsertRow();
	
	rowSet.updateString(1,guest.getFirstName());
	rowSet.updateString(2,guest.getLastName());
	rowSet.updateString(3,guest.getEmail());
	
	rowSet.insertRow();
	rowSet.moveToCurrentRow();
	rowSet.populate(rowSet);
	connection.setAutoCommit(false);
	rowSet.acceptChanges(connection);
}
	
}
