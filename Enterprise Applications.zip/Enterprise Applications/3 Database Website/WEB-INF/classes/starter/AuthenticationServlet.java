package starter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AuthenticationServlet extends HttpServlet{

	// process get request from client
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//get string from html
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		Boolean authenticated = false;
		
		//get credentials file
		File credentialsFile = new File("/opt/tomcat/webapps/Project4/WEB-INF/lib/credentials.txt");
		
		 try {
	            // open the file
	            FileReader fileReader = new FileReader(credentialsFile);
	            BufferedReader bufferedReader = new BufferedReader(fileReader);

	            // read the first line
	            String line = bufferedReader.readLine();
	            String[] lineParts = line.split(",");
	            
	            String user = lineParts[0];
	            String pass = lineParts[1];
	            
	            while (line != null && !authenticated) {
	            	System.out.println(line);
	            	if(username.equals(user) && password.equals(pass)) {
	                	authenticated = true;
	                	break;
	                }else {
	                	line = bufferedReader.readLine();
	    	            
	                	if(line == null) break;
	                	lineParts = line.split(",");
	    	            
	    	            user = lineParts[0];
	    	            pass = lineParts[1];
	                }
	            }

	            // close the file
	            bufferedReader.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		 
		 	if(authenticated) {
		 		//redirect to front end pages
		 		if(username.equals("root")) {
		 			response.sendRedirect("/Project4/rootHome.jsp");
		 		}else if(username.equals("client")) {
		 			response.sendRedirect("/Project4/clientHome.jsp");
		 		}else {
		 			response.sendRedirect("/Project4/dataEntryHome.jsp");
		 		}
		 	}else {
		 		//redirect to error page
	 			response.sendRedirect("/Project4/errorpage.html");
		 	}
	}
}
