package user;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.sql.Statement;
import java.sql.ResultSetMetaData;

import com.mysql.cj.jdbc.MysqlDataSource;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class ClientUserServlet extends HttpServlet {
	
	static Connection connection;
	private int mysqlUpdateValue;
	private int[] updateReturnValues;
    Properties properties = new Properties();
    FileInputStream filein = null;
    MysqlDataSource dataSource = null;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Call the doPost method to handle the GET request
        doPost(request, response);
    }
    
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		 String sqlStatement = "select * from jobs;";
		 sqlStatement = request.getParameter("command");
		 String tableHtml = "";
		 String query = "SELECT * FROM jobs";
		 
	      
		 try {
			 //get connection
			getDBConnection();
		    				 
			 //extract first word
			 String[] words = sqlStatement.trim().split(" ");
			 String firstWord = words[0].toLowerCase();
			 
			 if (firstWord.equals("select")) {
				 	// Create a PreparedStatement object to execute the query
		            PreparedStatement pst = connection.prepareStatement(sqlStatement);

		            // Execute the query and get the ResultSet object
		            ResultSet rs = pst.executeQuery();
		            
		            //get the html
		            tableHtml += getHtmlRows(rs);
		            rs.close();
				 

			 }else {
				 	// Create a PreparedStatement object to execute the query
		            PreparedStatement pst = connection.prepareStatement(sqlStatement);
	
		            // Execute the query and get the ResultSet object
		            pst.executeUpdate();
			 }

			 connection.close();
			 

			 
		 }catch (SQLException e){
				tableHtml="<h1>"+e.getMessage()+"</h1>";	
				e.printStackTrace();
		 }
		 
		 //session object
		 HttpSession session = request.getSession();
		 session.setAttribute("tableHtml", tableHtml);
		 
	     // Forward the request to the JSP page
		 RequestDispatcher dispatcher = request.getRequestDispatcher("/clientHome.jsp");
	     dispatcher.forward(request, response);
	}
	private void getDBConnection() {
	    Properties properties = new Properties();
	    FileInputStream filein = null;
	    MysqlDataSource dataSource = null;
	    //read a properties file
	    try {
	    	filein = new FileInputStream("/opt/tomcat/webapps/Project4/WEB-INF/lib/client.properties");
	    	properties.load(filein);
	    	dataSource = new MysqlDataSource();
	    	dataSource.setURL(properties.getProperty("MYSQL_DB_URL"));
	    	dataSource.setUser(properties.getProperty("MYSQL_DB_USERNAME"));
	    	dataSource.setPassword(properties.getProperty("MYSQL_DB_PASSWORD"));	 
	    	connection = dataSource.getConnection();
	    }
	    catch (SQLException e){
			e.printStackTrace();	
		}
	    catch (IOException e) {
	    	e.printStackTrace();
	    }
	}
	private static synchronized String getHtmlRows(ResultSet rs) throws SQLException{
		StringBuffer sb = new StringBuffer();
		
        // Get the ResultSetMetaData object to access the column names
        ResultSetMetaData rsmd = rs.getMetaData();

        // Start the HTML table
        sb.append("<table>");
        sb.append("<tr>");

        // Add the column names to the table header row
        for (int i = 1; i <= rsmd.getColumnCount(); i++) {
            sb.append("<th>").append(rsmd.getColumnName(i)).append("</th>");
        }

        sb.append("</tr>");

        // Add the data rows to the table
        while (rs.next()) {
            sb.append("<tr>");

            // Add the values for each column to the row
            for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                sb.append("<td>").append(rs.getString(i)).append("</td>");
            }

            sb.append("</tr>");
        }

        // End the HTML table
        sb.append("</table>");

		
		return sb.toString();
		
		
	}

}
