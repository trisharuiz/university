package user;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.sql.Statement;
import java.sql.ResultSetMetaData;

import com.mysql.cj.jdbc.MysqlDataSource;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class MyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	String sqlStatement = request.getParameter("command");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String url = "jdbc:mysql://localhost:3306/project4";
        String user = "client";
        String password = "trisharon17";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, user, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from jobs;");

            StringBuffer buffer = new StringBuffer();
            buffer.append("<table>");
            buffer.append("<tr>");
            ResultSetMetaData meta = rs.getMetaData();
            int columnCount = meta.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                buffer.append("<th>").append(meta.getColumnName(i)).append("</th>");
            }
            buffer.append("</tr>");
            while (rs.next()) {
                buffer.append("<tr>");
                for (int i = 1; i <= columnCount; i++) {
                    buffer.append("<td>").append(rs.getString(i)).append("</td>");
                }
                buffer.append("</tr>");
            }
            buffer.append("</table>");

            HttpSession session = request.getSession();
            session.setAttribute("htmlTable", buffer.toString());

            conn.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        HttpSession session = request.getSession();
        String htmlTable = (String) session.getAttribute("htmlTable");
        request.getRequestDispatcher("/clientHome.jsp").forward(request, response);
    }
}
