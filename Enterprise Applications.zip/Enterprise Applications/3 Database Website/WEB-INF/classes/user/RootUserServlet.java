package user;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.sql.Statement;
import java.sql.ResultSetMetaData;

import com.mysql.cj.jdbc.MysqlDataSource;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class RootUserServlet extends HttpServlet {
	
	static Connection connection;
	private int mysqlUpdateValue;
	private int[] updateReturnValues;
    Properties properties = new Properties();
    FileInputStream filein = null;
    MysqlDataSource dataSource = null;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Call the doPost method to handle the GET request
        doPost(request, response);
    }
    
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		 String sqlStatement = "select * from jobs;";
		 sqlStatement = request.getParameter("command");
		 String tableHtml = "";
		 String query = "SELECT * FROM jobs";
		 
	      
		 try {
			 //get connection
			getDBConnection();
		    				 
			 //extract first word
			 String[] words = sqlStatement.trim().split(" ");
			 String firstWord = words[0].toLowerCase().trim();
			 String thirdWord = words[1].toLowerCase().trim();
			 
			 if (firstWord.equals("select")) {
				 	// Create a PreparedStatement object to execute the query
		            PreparedStatement pst = connection.prepareStatement(sqlStatement);

		            // Execute the query and get the ResultSet object
		            ResultSet rs = pst.executeQuery();
		            
		            //get the html
		            tableHtml += getHtmlRows(rs);
		            rs.close();
				 

			 }else {
		            
				 	tableHtml = executeUpdate(sqlStatement, firstWord, thirdWord);	            
		            
			 }

			 connection.close();
			 

			 
		 }catch (SQLException e){
				tableHtml="<h1>ERROR:"+e.getMessage()+sqlStatement+"</h1>";	
				e.printStackTrace();
		 }
		 
		 //session object
		 HttpSession session = request.getSession();
		 session.setAttribute("tableHtml", tableHtml);
		 
	     // Forward the request to the JSP page
		 RequestDispatcher dispatcher = request.getRequestDispatcher("/rootHome.jsp");
	     dispatcher.forward(request, response);
	}
	private void getDBConnection() {
	    Properties properties = new Properties();
	    FileInputStream filein = null;
	    MysqlDataSource dataSource = null;
	    //read a properties file
	    try {
	    	filein = new FileInputStream("/opt/tomcat/webapps/Project4/WEB-INF/lib/root.properties");
	    	properties.load(filein);
	    	dataSource = new MysqlDataSource();
	    	dataSource.setURL(properties.getProperty("MYSQL_DB_URL"));
	    	dataSource.setUser(properties.getProperty("MYSQL_DB_USERNAME"));
	    	dataSource.setPassword(properties.getProperty("MYSQL_DB_PASSWORD"));	 
	    	connection = dataSource.getConnection();
	    }
	    catch (SQLException e){
			e.printStackTrace();	
		}
	    catch (IOException e) {
	    	e.printStackTrace();
	    }
	}

	private static synchronized String getHtmlRows(ResultSet rs) throws SQLException{
		StringBuffer sb = new StringBuffer();
		
        // Get the ResultSetMetaData object to access the column names
        ResultSetMetaData rsmd = rs.getMetaData();

        // Start the HTML table
        sb.append("<table>");
        sb.append("<tr>");

        // Add the column names to the table header row
        for (int i = 1; i <= rsmd.getColumnCount(); i++) {
            sb.append("<th>").append(rsmd.getColumnName(i)).append("</th>");
        }

        sb.append("</tr>");

        // Add the data rows to the table
        while (rs.next()) {
            sb.append("<tr>");

            // Add the values for each column to the row
            for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                sb.append("<td>").append(rs.getString(i)).append("</td>");
            }

            sb.append("</tr>");
        }

        // End the HTML table
        sb.append("</table>");

		
		return sb.toString();
		
		
	}
	private static synchronized String executeUpdate(String sqlStatement, String firstWord, String thirdWord) throws SQLException {
		
		StringBuffer sb = new StringBuffer();
		int quant = 0;
		Boolean fired = false;
		PreparedStatement pst = null;
		
		
		//first execute what user input
		 
	 	// Create a PreparedStatement object to execute the query
        pst = connection.prepareStatement(sqlStatement);
        // Execute the update and get the ResultSet object
        int rows = pst.executeUpdate();
        
        
        //start our output html
        sb.append("<h1> The statement executed successfully. \n"
        		+ rows+ " row(s) affected.\n");
        
        //if anything involves shipments the business logic will trigger
        if(sqlStatement.contains("shipments")) {
        	sb.append("\nBusiness Logic Detected! - Updating Supplier Status\n");
        	
        	
        	//if quantity inserted is >= 100 then it will fire
            if(firstWord.equals("insert")) {
            	String quantity = sqlStatement.substring(sqlStatement.lastIndexOf(",")+1, sqlStatement.indexOf(")")).trim();
            	quant = Integer.parseInt(quantity);
            	
            	if(quant >= 100) {
            		fired = true;
            	}else {
            		sb.append("Business Logic updated 0 supplier status marks.");
            	}
            	
           //updates: if quantity updated is >= 100
            }else if (firstWord.equals("update") && sqlStatement.contains("quantity")){ 
            	
            	fired = true;
        }
        
        
        
        
        if(fired) {
	        //then count how many was effected            
	        pst = connection.prepareStatement("select count(snum) as count from suppliers where  snum in ( select snum from shipments where quantity >= 100);");
	        //get count of joint table to see if logic is detected.
	        ResultSet joint = pst.executeQuery();
	        
	        int numCount = 0;
	        if(joint.next()){
		        //get number of rows that meets condition
		        numCount = joint.getInt("count");
		        joint.close();
	        }        

        	sb.append("Business Logic updated "+ numCount +" supplier status marks.");
        	
        	//update status
            pst = connection.prepareStatement("update suppliers"
            		+ " set status = status + 5 where  snum in"
            		+"( select snum from shipments where quantity >= 100);");
            pst.executeUpdate();
        }
        
        //end our html
        
        
	}else {
    	sb.append("\nBusiness Logic Not Triggered!");
    }
        sb.append("</h1>");
        return sb.toString();
	}

}
