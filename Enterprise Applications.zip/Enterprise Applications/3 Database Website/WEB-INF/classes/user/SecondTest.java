package user;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.sql.Statement;
import java.sql.ResultSetMetaData;

import com.mysql.cj.jdbc.MysqlDataSource;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class SecondTest extends HttpServlet {

    private static final long serialVersionUID = 1L;
	static Connection con;

    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Call the doPost method to handle the GET request
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Set the content type and encoding
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        // Get the PrintWriter object to write the HTML response
        PrintWriter out = response.getWriter();

        // Set up the database connection and query
        String url = "jdbc:mysql://localhost:3306/project4";
        String username = "client";
        String password = "trisharon17";
        String query = "SELECT * FROM jobs";

        // Create a StringBuffer to hold the HTML table
        StringBuffer sb = new StringBuffer();

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the database connection
            getDBConnection();

            // Create a PreparedStatement object to execute the query
            PreparedStatement pst = con.prepareStatement(query);

            // Execute the query and get the ResultSet object
            ResultSet rs = pst.executeQuery();

            // Get the ResultSetMetaData object to access the column names
            ResultSetMetaData rsmd = rs.getMetaData();

            // Start the HTML table
            sb.append("<table>");
            sb.append("<tr>");

            // Add the column names to the table header row
            for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                sb.append("<th>").append(rsmd.getColumnName(i)).append("</th>");
            }

            sb.append("</tr>");

            // Add the data rows to the table
            while (rs.next()) {
                sb.append("<tr>");

                // Add the values for each column to the row
                for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                    sb.append("<td>").append(rs.getString(i)).append("</td>");
                }

                sb.append("</tr>");
            }

            // End the HTML table
            sb.append("</table>");

            // Close the database resources
            rs.close();
            pst.close();
            con.close();

        } catch (Exception e) {
            // Handle any errors that may occur
            e.printStackTrace();
        }

        // Store the HTML table in the session
        HttpSession session = request.getSession();
        session.setAttribute("htmlTable", sb.toString());

        // Forward the request to the JSP page
        RequestDispatcher rd = request.getRequestDispatcher("test.jsp");
        rd.forward(request, response);

    }
    
	private void getDBConnection() {
	    Properties properties = new Properties();
	    FileInputStream filein = null;
	    MysqlDataSource dataSource = null;
	    //read a properties file
	    try {
	    	filein = new FileInputStream("/opt/tomcat/webapps/Project4/WEB-INF/lib/client.properties");
	    	properties.load(filein);
	    	dataSource = new MysqlDataSource();
	    	dataSource.setURL(properties.getProperty("MYSQL_DB_URL"));
	    	dataSource.setUser(properties.getProperty("MYSQL_DB_USERNAME"));
	    	dataSource.setPassword(properties.getProperty("MYSQL_DB_PASSWORD"));	 
	    	con = dataSource.getConnection();
	    }
	    catch (SQLException e){
			e.printStackTrace();	
		}
	    catch (IOException e) {
	    	e.printStackTrace();
	    }
	}

}
